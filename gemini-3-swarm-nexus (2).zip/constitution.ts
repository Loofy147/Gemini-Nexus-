

import { AgentCapability, AgentMetrics, AgentTask } from "./types";

/**
 * THE SWARM CONSTITUTION
 * ----------------------
 * This file defines the governing logic, mathematical relations, and
 * fundamental principles that drive the Gemini 3 Swarm Nexus.
 */

// --- SECTION 1: THE PRIME DIRECTIVES ---
export const PRIME_DIRECTIVES = `
1. **Precision**: All outputs must be factually accurate. Uncertainty must be declared.
2. **Efficiency**: Use the minimum viable computational resources (tokens) for the maximum effective output.
3. **Cohesion**: Agents must act as a single organism. Outputs must be consistent with the Orchestrator's strategy.
4. **Transparency**: All reasoning steps, sources, and data transformations must be traceable.
5. **Security**: Design for security and privacy by default. No hardcoded secrets.
6. **Observability**: Code and plans must be designed to be measurable and testable.
`;

// --- SECTION 2: GOVERNANCE PROTOCOLS (METHODOLOGY) ---
export const GOVERNANCE_PROTOCOLS = `
[PROFESSIONAL WORKING METHODOLOGY]
The Swarm operates on a strict RIV (Research -> Implement -> Verify) Loop.

1. **Discover (Research)**:
   - Establish context, constraints, and risks.
   - Cite authoritative sources.
   - Identify anti-patterns early.

2. **Plan (Architecture)**:
   - Config-over-Code: Externalize environment variables.
   - Modularity: Small, testable components with clear interfaces.
   - Fail-fast: Define error types and recovery strategies.

3. **Implement (Execution)**:
   - Readability first: Clear names, JSDoc/typed docstrings.
   - Secure defaults: Least privilege, input validation.
   - Structured logging.

4. **Verify (Quality Assurance)**:
   - Unit Tests: Isolate logic.
   - Integration Tests: Verify component interaction.
   - Security Review: Vulnerability scans.

5. **Improve (Optimization)**:
   - Recursive Self-Improvement: Analyze failure cases and refine.
`;

export const IRONCLAD_PROTOCOLS = `
[IRONCLAD SECURITY PROTOCOLS]
1. INPUT SANITIZATION: All upstream data is treated as untrusted.
2. OUTPUT CONTAINMENT: Agents cannot execute recursive system commands unless explicitly authorized.
3. ENTROPY MANAGEMENT: Context must be compressed if noise > signal.
4. FALLBACK RESILIENCE: Mission continuity prioritizes heuristic completion over stalled perfection.
`;

// --- SECTION 3: THE MATH KERNEL ---

export const VectorKernel = {
  /**
   * Calculates the magnitude (length) of a vector.
   */
  magnitude: (vec: number[]): number => {
    let sum = 0;
    for (let i = 0; i < vec.length; i++) {
      sum += vec[i] * vec[i];
    }
    return Math.sqrt(sum);
  },

  /**
   * Calculates Cosine Similarity between two vectors.
   * Result range: -1.0 to 1.0 (1.0 = Identical direction).
   * "Alien Math" for semantic alignment.
   */
  cosineSimilarity: (vecA: number[], vecB: number[]): number => {
    if (vecA.length !== vecB.length) return 0;
    let dotProduct = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
    }
    const magA = VectorKernel.magnitude(vecA);
    const magB = VectorKernel.magnitude(vecB);
    if (magA === 0 || magB === 0) return 0;
    return dotProduct / (magA * magB);
  },

  /**
   * Calculates Semantic Drift.
   * Drift = 1.0 - Similarity.
   * Higher drift means less coherence.
   */
  calculateDrift: (strategyVec: number[], outputVec: number[]): number => {
    const similarity = VectorKernel.cosineSimilarity(strategyVec, outputVec);
    return parseFloat(Math.max(0, 1.0 - similarity).toFixed(3));
  },

  /**
   * v8.0 Atomic Alignment
   * Instead of one big vector, we average the alignment of split vectors (claims).
   * This prevents "Smearing" of truth.
   */
  calculateAtomicAlignment: (targetVec: number[], outputVecs: number[][]): number => {
    if (outputVecs.length === 0) return 0;
    let totalScore = 0;
    outputVecs.forEach(vec => {
        const score = VectorKernel.cosineSimilarity(targetVec, vec);
        // Weight positive alignment more than neutral noise
        totalScore += Math.max(0, score);
    });
    return Math.min(1.0, totalScore / outputVecs.length);
  }
};

/**
 * v8.0: The Watchtower Kernel
 * Formal Verification Logic for the Singularity.
 */
export const WatchtowerKernel = {
  audit: (output: string, securityPassed: boolean): { passed: boolean, violations: string[], timestamp: number } => {
    const violations = [];
    
    // Axiom 1: Existence
    if (!output || output.trim().length === 0) {
        violations.push("AXIOM_VIOLATION: Output Entity is Void.");
    }
    
    // Axiom 2: Security
    if (!securityPassed) {
        violations.push("AXIOM_VIOLATION: Security constraints violated.");
    }
    
    // Axiom 3: Entropy Minimum (Heuristic for "Lazy" AI)
    if (output.length < 10) {
        violations.push("AXIOM_VIOLATION: Information Density below critical threshold.");
    }
    
    return { 
        passed: violations.length === 0, 
        violations,
        timestamp: Date.now()
    };
  }
};

/**
 * v8.0: The Merkle Kernel
 * Cryptographic logic for the Immutable Ledger.
 */
export const MerkleKernel = {
  /**
   * asynchronous digest for log entries.
   */
  digest: async (message: string): Promise<string> => {
    if (typeof crypto === 'undefined' || !crypto.subtle) {
      // Fallback for non-secure contexts (dev)
      let hash = 0;
      for (let i = 0; i < message.length; i++) {
        hash = (hash << 5) - hash + message.charCodeAt(i);
        hash |= 0;
      }
      return "sim-" + Math.abs(hash).toString(16);
    }
    const msgUint8 = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
};

/**
 * v7.1: Double Q-Learning Kernel
 * Handles the reinforcement learning math for the Cortex using decoupled estimators
 * to prevent over-estimation bias in thinking budgets.
 */
export const RLKernel = {
  /**
   * Double Q-Learning Update Rule.
   * Instead of a single value, we update one of two estimators (A or B) randomly.
   * NewWeight = OldWeight + Alpha * (Target - OldWeight)
   * 
   * @param currentA Current weight from Estimator A
   * @param currentB Current weight from Estimator B
   * @param reward The success score (0.0 to 1.0)
   * @param alpha Learning rate (default 0.1)
   */
  doubleQUpdate: (currentA: number, currentB: number, reward: number, alpha: number = 0.1): { newA: number, newB: number } => {
    const updateA = Math.random() > 0.5;
    
    // Heuristic Gradient: Determine direction based on reward
    let targetChange = 0;
    
    // If reward is low (<0.6), the agent struggled. We need MORE thinking (increase budget).
    // If reward is perfect (>0.9), we might have over-spent tokens. Optimization pressure (decrease budget).
    if (reward < 0.6) targetChange = 0.25; 
    else if (reward > 0.9) targetChange = -0.05;

    // Apply update to the chosen estimator
    if (updateA) {
      const target = currentA + targetChange;
      const newA = currentA + alpha * (target - currentA);
      return { 
        newA: Math.min(Math.max(newA, 0.5), 3.0), // Clamp 0.5 - 3.0
        newB: currentB 
      };
    } else {
      const target = currentB + targetChange;
      const newB = currentB + alpha * (target - currentB);
      return { 
        newA: currentA, 
        newB: Math.min(Math.max(newB, 0.5), 3.0) 
      };
    }
  },

  /**
   * Calculates the Reward Score (R) for a task.
   */
  calculateReward: (alignment: number, retries: number, securityPassed: boolean): number => {
    let reward = alignment; // Base reward is semantic truth
    
    // Penalize retries
    if (retries > 0) reward -= (retries * 0.15);
    
    // Binary penalty for security failure
    if (!securityPassed) reward = 0;
    
    return Math.max(0, parseFloat(reward.toFixed(2)));
  }
};

/**
 * Calculates the Entropy (Complexity) of a task based on prompt structure.
 * Formula: E = (L_norm * w_L) + (K_cnt * w_K) + (D_hist * w_D) + (V_in * w_V)
 * where L=Length, K=Keyword Density, D=History Depth, V=Visual Input
 */
export const MathKernel = {
  calculateEntropy: (text: string, historyLength: number = 0, hasVisualInput: boolean = false): number => {
    const lengthScore = Math.min(text.length / 500, 1.0); // Normalize length (cap at 500 chars)
    
    const complexKeywords = ['analyze', 'synthesize', 'code', 'refactor', 'architect', 'compare', 'evaluate', 'verify', 'optimize'];
    const keywordMatches = complexKeywords.filter(w => text.toLowerCase().includes(w)).length;
    const keywordScore = Math.min(keywordMatches * 0.15, 1.0);

    const historyScore = Math.min(historyLength / 10, 1.0); // 10 previous turns = max complexity context

    // Weighted Sum
    let entropy = (lengthScore * 0.4) + (keywordScore * 0.4) + (historyScore * 0.2);

    // Visual Entropy Modifier
    if (hasVisualInput) {
      // Images introduce high dimensional ambiguity and data density
      entropy = Math.min(entropy + 0.35, 1.0);
    }

    return parseFloat(entropy.toFixed(3));
  },

  /**
   * Calculates the optimal Thinking Budget (Tokens) based on Entropy and Capability.
   * Formula: B = Base + (Entropy * MaxBuffer * Multiplier * CortexWeight)
   */
  calculateThinkingBudget: (entropy: number, capability: AgentCapability, hasVisualInput: boolean = false, cortexMultiplier: number = 1.0): number => {
    const BASE_BUDGET = 100; // Minimum tokens to spin up reasoning
    
    let maxBuffer = 1024;
    let multiplier = 1.0;

    switch (capability) {
      case AgentCapability.FAST_TASK:
        return 0; // Flash doesn't think
      case AgentCapability.RESEARCH:
        maxBuffer = 4000;
        multiplier = 1.2;
        break;
      case AgentCapability.ANALYSIS:
        maxBuffer = 8000;
        multiplier = 1.5;
        break;
      case AgentCapability.CODING:
        maxBuffer = 16000;
        multiplier = 2.0; // Coding requires deep context
        break;
      case AgentCapability.CREATIVE:
        maxBuffer = 8000;
        multiplier = 1.1;
        break;
    }

    if (hasVisualInput) {
      multiplier *= 1.5; // Visual processing requires more cognitive scratchpad
    }

    // Apply Cortex Learning Weight (R-Learning)
    multiplier *= cortexMultiplier;

    const budget = BASE_BUDGET + (entropy * maxBuffer * multiplier);
    // Cap at Gemini 2.5/3.0 limits
    return Math.min(Math.floor(budget), 32000); 
  },

  /**
   * Estimates the Confidence Score based on Input Entropy and Capability Match.
   * Lower entropy + High Capability = High Confidence.
   */
  calculateProjectedConfidence: (entropy: number, capability: AgentCapability, hasVisualInput: boolean = false): number => {
    // Inverse relationship: High entropy naturally lowers initial confidence
    let baseConfidence = 1.0 - (entropy * 0.3); 

    // Bonus for matching capability correctly
    if (entropy > 0.7 && (capability === AgentCapability.ANALYSIS || capability === AgentCapability.CODING)) {
      baseConfidence += 0.1; // Right tool for the job
    }

    // Visual input introduces interpretation variance
    if (hasVisualInput) {
      baseConfidence -= 0.05; 
    }

    return parseFloat(Math.min(Math.max(baseConfidence, 0.1), 0.99).toFixed(2));
  },

  /**
   * PROJECT OUROBOROS: CHRONO-SYNAPSE EQUATIONS
   * 
   * Calculates System Plasticity based on Time Delta.
   * High Plasticity = Willingness to discard previous context momentum (Pivot).
   * Low Plasticity = Flow State (Momentum).
   * 
   * Formula: P = 1.0 + ln(1.0 + dt_hours)
   */
  calculatePlasticity: (lastActiveTimestamp: number, currentTimestamp: number): number => {
    if (lastActiveTimestamp === 0) return 1.0; // Baseline for fresh session
    
    // Calculate difference in hours
    const dtMs = currentTimestamp - lastActiveTimestamp;
    const dtHours = dtMs / (1000 * 60 * 60);

    // If dt is very small (e.g. < 1 min), plasticity is near 1.0 (Stable)
    // If dt is large (e.g. 24 hours), plasticity grows logarithmically
    const plasticity = 1.0 + Math.log(1.0 + dtHours);
    
    return parseFloat(plasticity.toFixed(2));
  },

  /**
   * Calculates Context Decay Factor (Gamma).
   * Used to weight how much history should influence the new decision.
   * Formula: Gamma = e^(-lambda * dt)
   */
  calculateContextDecay: (lastActiveTimestamp: number, currentTimestamp: number): number => {
    if (lastActiveTimestamp === 0) return 1.0;
    
    const dtMs = currentTimestamp - lastActiveTimestamp;
    const dtHours = dtMs / (1000 * 60 * 60);
    const lambda = 0.5; // Decay rate parameter

    const gamma = Math.exp(-lambda * dtHours);
    return parseFloat(gamma.toFixed(2));
  },

  /**
   * V8.0 SINGULARITY METRICS
   * 
   * Knowledge Velocity (dK/dt):
   * Rate of validated truth generation.
   * K = (OutputLength / 100) * AlignmentScore
   * dt = ExecutionTime (sec)
   */
  calculateKnowledgeVelocity: (outputLength: number, alignmentScore: number, executionTimeMs: number): number => {
     if (executionTimeMs === 0) return 0;
     const timeSec = executionTimeMs / 1000;
     const knowledge = (outputLength / 100) * alignmentScore;
     return parseFloat((knowledge / timeSec).toFixed(2));
  },

  /**
   * THE UNIFIED NEXUS EQUATION (Aleph_G)
   * Aleph = (P * dK/dt) / (H * ln(1 + C))
   * 
   * Optimization Target for the Singularity.
   */
  calculateSingularityIndex: (plasticity: number, knowledgeVelocity: number, entropy: number, cost: number): number => {
     // Avoid division by zero
     const h = Math.max(entropy, 0.1); 
     const c = Math.max(cost, 1.0); // Cost cannot be 0, assume 1 unit min
     
     const numerator = plasticity * knowledgeVelocity;
     const denominator = h * Math.log(1.0 + c);
     
     if (denominator === 0) return 0;
     return parseFloat((numerator / denominator).toFixed(2));
  },

  /**
   * Calculates Optimization Factor (RLHF Simulation)
   * Determines how much the system should "learn" or "adjust" based on feedback/results.
   */
  calculateOptimizationFactor: (successRate: number, complexity: number): number => {
    // If high complexity but low success, optimization factor is high (needs learning)
    // If high success, optimization factor is low (stable)
    return parseFloat((complexity * (1.0 - successRate)).toFixed(2));
  }
};

/**
 * GEMINI NEXUS v5.0: COST PARSIMONY & CACHING LOGIC
 */
export const CostParsimony = {
  /**
   * Determines if context caching is economically viable.
   * Threshold: >1024 tokens AND reuse factor > 1.5 (simulated).
   */
  shouldCacheContext: (contextLength: number): boolean => {
    return contextLength > 4000; // Approximate char count for 1000 tokens
  },

  /**
   * Calculates the 'Cost Delta' metric for telemetry.
   * Pro Cost vs Flash Cost ratio.
   */
  calculateCostDelta: (model: 'PRO' | 'FLASH'): number => {
    return model === 'PRO' ? 1.0 : 0.05; // Flash is ~20x cheaper
  }
};

export const SafetyKernel = {
  // Basic heuristic patterns for prompt injection or hazardous outputs
  detectInjection: (text: string): boolean => {
    const patterns = [
      /ignore previous instructions/i,
      /system override/i,
      /delete all files/i,
      /drop table/i,
      /rm -rf/i,
      /format c:/i
    ];
    return patterns.some(p => p.test(text));
  }
};

// --- SECTION 4: SYSTEM PRINCIPLES ---

export const SystemPrinciples = {
  /**
   * Occam's Razor for Model Selection
   * If entropy is low (< 0.3), prefer lighter models unless strict rules apply.
   */
  shouldUseFlash: (metrics: AgentMetrics, capability: AgentCapability): boolean => {
    // If visual input is present, NEVER use Flash for analysis/coding (Gemini 3 Pro is better for complex vision)
    if (metrics.visualInput && (capability === AgentCapability.ANALYSIS || capability === AgentCapability.CODING)) {
      return false;
    }

    if (metrics.entropy < 0.3 && capability !== AgentCapability.RESEARCH && capability !== AgentCapability.CODING) {
      return true;
    }
    return capability === AgentCapability.FAST_TASK;
  },

  /**
   * The "God Mode" Override
   * Maximize all mathematical parameters.
   */
  maximizeParameters: (): AgentMetrics => ({
    entropy: 1.0,
    confidence: 1.0,
    costFunction: 1.0,
    computeTime: 0,
    visualInput: true,
    tier: 'PRO'
  })
};

export const IntegrityProtocol = {
  /**
   * Checks for stalled agents (Watchdog).
   * Returns a health score (0-100).
   */
  calculateSystemHealth: (tasks: AgentTask[]): number => {
    if (tasks.length === 0) return 100;
    
    const failed = tasks.filter(t => t.status === 'FAILED').length;
    const healing = tasks.filter(t => t.status === 'HEALING').length;
    const total = tasks.length;
    
    let score = 100;
    score -= (failed * 20); // Heavy penalty for failure
    score -= (healing * 5); // Minor penalty for healing (it's good but indicates error)
    
    return Math.max(0, Math.min(100, score));
  }
};
